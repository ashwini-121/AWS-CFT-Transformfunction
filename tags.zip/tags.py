response = client.tag_resource(
    ResourceARN='string',
    Tags=[
        {
            'Key': 'uai',
            'Value': 'test'
        },
    ]
)